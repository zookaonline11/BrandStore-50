"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { loginUser } from "@/app/actions/auth-actions"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showForgotPassword, setShowForgotPassword] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const formData = new FormData(e.currentTarget)
    const result = await loginUser(formData)

    if (result.error) {
      setError(result.error)
      setIsLoading(false)
    } else {
      if (result.role === "admin") {
        router.push("/admin/dashboard")
      } else {
        router.push("/customer/dashboard")
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-slate-700 bg-slate-800">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-white">Brand Store</CardTitle>
          <CardDescription className="text-slate-400">تسجيل الدخول</CardDescription>
        </CardHeader>
        <CardContent>
          {!showForgotPassword ? (
            <form onSubmit={handleLogin} className="space-y-4">
              {error && (
                <div className="bg-red-500/20 border border-red-500 text-red-200 px-4 py-2 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-200">
                  البريد الإلكتروني أو رقم الهاتف
                </Label>
                <Input
                  id="email"
                  name="email"
                  placeholder="example@gmail.com"
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-200">
                  كلمة المرور
                </Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="••••••••"
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                  required
                />
              </div>

              <Button type="submit" disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                {isLoading ? "جاري التسجيل..." : "تسجيل الدخول"}
              </Button>

              <Button
                type="button"
                onClick={() => setShowForgotPassword(true)}
                variant="ghost"
                className="w-full text-blue-400 hover:text-blue-300 hover:bg-transparent"
              >
                هل نسيت كلمة المرور؟
              </Button>

              <p className="text-sm text-slate-400 text-center">
                ليس لديك حساب؟{" "}
                <Link href="/" className="text-blue-400 hover:text-blue-300">
                  قم بالتسجيل
                </Link>
              </p>
            </form>
          ) : (
            <div className="space-y-4">
              <p className="text-slate-300 text-sm">أدخل بريدك الإلكتروني لإعادة تعيين كلمة المرور</p>
              <Input
                type="email"
                placeholder="example@gmail.com"
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
              />
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">احصل على الكود</Button>
              <Button type="button" onClick={() => setShowForgotPassword(false)} variant="outline" className="w-full">
                رجوع
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
